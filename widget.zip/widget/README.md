# MobCoder Chat Widget — `demo.html`

Single local demo page (full-page chat UI). All widget logic lives inline in `demo.html` — no separate JS bundle.

## Run

**Terminal 1 — API:**

```bash
python main.py
```

**Terminal 2 — widget:**

```bash
cd widget
python -m http.server 8765
```

Open **http://127.0.0.1:8765/demo.html**

Ensure API `CORS_ALLOWED_ORIGINS` includes `http://127.0.0.1:8765` and `http://localhost:8765`.

## Config (top of `demo.html` script block)

| Constant | Purpose |
|----------|---------|
| `API_URL` | `POST /api/v1/chat` |
| `STREAM_URL` | `POST /api/v1/chat/stream` (SSE) |
| `USE_STREAM` | `true` = token streaming |
| `DEMO_PAGE_URL` | Simulated page URL for retrieval + chips |

## Lead capture (user details)

Popup modal (center of chat, × to close) opens **automatically** when:

| Trigger | When |
|---------|------|
| API asks for contact | `needs_contact_info` after a reply |
| Human escalation | Agent offers “talk to our team” |
| Ready to book | `ready_for_booking` and no email yet |
| After **2 chat messages** | Soft prompt if email not collected |

User can also open anytime via **Share details** in the header.

Inspect: `python scripts/inspect_db.py`

## Development vs production API

`demo.html` picks the API base automatically:

| Where you open the widget | API calls go to |
|---------------------------|-----------------|
| `http://127.0.0.1:8765` or `localhost` | `http://127.0.0.1:8001` |
| `https://devweb-agent.mobcoder.ai` | `https://devapi-chatbot.mobcoder.ai` (widget on S3/CloudFront, API separate) |
| Anything else | `https://api.mobcoder.ai` (production) |

Local `.env`:

```bash
MOBCODER_WIDGET_URL=https://devweb-agent.mobcoder.ai
MOBCODER_DEV_API_BASE=https://devapi-chatbot.mobcoder.ai
MOBCODER_CHAT_API_URL=https://devapi-chatbot.mobcoder.ai/api/v1/chat
CORS_ALLOWED_ORIGINS=...,https://devweb-agent.mobcoder.ai,...
```

On **AWS dev**, widget and API are on different hosts — no nginx proxy needed on the widget domain. Upload `demo.html` to the S3 bucket behind `devweb-agent.mobcoder.ai`.

## Fresh session

Clear `localStorage` key `mc_session_id` or use incognito.
